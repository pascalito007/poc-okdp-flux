# Composition engine spec, v2 (engine-independent)

Any engine that reads the **inputs** below and writes `plan.json` according to these rules is a valid OKDP composition engine. The reference implementation is the CUE engine (`engine-cue/`, with its mappings in `engine-cue/mappings/*.cue`, run by `engine-cue/compose.sh`). Its emitters (`engine-cue/emit/`) only read `plan.json`.

**Conformance.** For every platform in `platforms/`, an engine must produce a `plan.json` equal to the golden plan `out/<platform>/plan.json` after `jq -S .` (key order is irrelevant; **list order and every string byte are significant**). For every file in `tests/negative/`, it must fail with the error of §11 that the file name announces (`tests/run.sh` checks the CUE wording; for schema violations, E16, another engine's message must at least name the offending field). The golden plans are **normative** for the unit values: where this text and a golden plan disagree, the golden plan wins and the disagreement is a spec bug to report.

v1 → v2 changes are summarised in §12. The ENGINE-SPEC v1 rules that are not restated here are replaced.

**This demo copy differs from `poc/ENGINE-SPEC.md` on one point:** there are no families. A slot lists the contracts it accepts (`accepts:`), contracts have no `family`, and `catalog/families/` does not exist (§2, §5, §11). Plans are unchanged.

---

## 1. Inputs

| Input | Files | `kind` |
|---|---|---|
| Contracts | `catalog/contracts/*.yaml` | `Contract` |
| Service definitions | `catalog/services/*.yaml` | `ServiceDefinition` |
| Provisioner sets | `catalog/provisioners/*.yaml` | `ProvisionerSet` |
| Platform (one per run) | `platforms/<name>.yaml` | `Platform` |
| Value mappings | `engine-cue/mappings/*` | engine-specific code, normative behaviour in §10 |

All objects have `apiVersion: okdp.io/v1alpha1`. Objects are keyed by `metadata.name` (unique per kind). Unknown keys anywhere in these files are an error (the shapes in §2 are closed), except inside JSON Schemas, `values`, `parameters`, `claim`, `defaults`, `binding` and `endpoint`.

Catalog charts (OKDP-owned Helm charts) live in `catalog/charts/<name>`; they are data for the emitters/tests, not engine input.

## 2. Shapes (defaults in brackets)

```yaml
Contract: metadata: { name, version: "<major>.<minor>.<patch>" }
          spec: { technology, class, description,
                  claim: <JSON Schema object>, binding: <JSON Schema object>,
                  derived: { <binding key>: <template> },
                  secret: { bindingType, required: [..], optional: [..] } }
ServiceDefinition: metadata: { name, version }
          spec: { description,
                  chart: { repository, name, version }          # exactly one of chart / components
                  components: [ { name, chart, needs: [component names] [[]], values [{}] } ],
                  values [{}],                                  # static values (single-chart services)
                  capabilities [[]], profileCapabilities [{}] ({<profile key>: [capabilities]}),
                  requiresProfile [[]], offersCapabilities [[]],
                  connexions [{}]: { <slot>: { accepts: [contract names], optional [false], many [false],
                                             defaults [{}]: { <contract name>: {..} } } },  # overrides the contract's claim defaults
                  provides [[]]: [ { contract, modes: [..] } ],
                  mapping: <mapping name> | none }
ProvisionerSet: spec: { contract, provisioners: [ { name, provider: service/<svc> | external/<kind> | any,
                                                    modes: [..], chart: { path, name, version }, capabilities: [..] } ] }
Platform: metadata: { name, description? }
          spec: { namespace, profile [{}]: { domain?, ingressClass?, clusterIssuer?, trustBundle?, storageClass? },
                  secretStore?: { kind, name }, delivery: { okdpCharts },
                  preinstalledCapabilities [[]],
                  instances: { <name>: { service, namespace?, parameters [{}], connect [{}] } },
                  externals [{}]: { <name>: { kind, offers: [contract names], endpoint [{}], adminSecretRef? } } }
Connection (value of connect.<slot>, or of connect.<slot>.<key> when the slot is many):
          { mode: dedicated|tenant|existing|bind, provider: <instance or external name> | { service, parameters [{}] },
            contract?, claim [{}], binding?, secret?: { key, properties: {<secret key>: <store property>} } }
```

`provider` is an object only in mode `dedicated`.

## 3. Names (all derived strings are case-sensitive; "lowercase" is ASCII lower-casing)

| Name | Rule | Example |
|---|---|---|
| connection **id** | `consumer.slot` or `consumer.slot.key` (slot as written in the definition) | `trino.catalogStorage.hive` |
| **suffix**(id) | lowercase(id), `.` → `-` | `trino-catalogstorage-hive` |
| **ident**(id) | lowercase(id), `.` and `-` → `_` | `trino_catalogstorage_hive` |
| binding Secret | `okdp-bind-` + suffix (only if the contract has secret keys and mode ≠ bind) | `okdp-bind-hive-db` |
| provisioner unit | `bind-` + suffix (same condition) | `bind-hive-db` |
| provider-side objects of a provisioner | `okdp-src-` + suffix (made by the provisioner chart, not by the engine) | `okdp-src-hive-db` |
| dedicated provider instance | `<consumer>-` + lowercase(slot), in the consumer's namespace | `hub-hubdb` |
| unit of an instance | `<instance>` (single chart) or `<instance>-<component>` (one per component) | `polaris-server` |
| public host of an instance | `<instance>.<profile.domain>` | `superset.okdp.sandbox` |
| env var for secret key *k* of binding *b* | `OKDP_` + upper(suffix(b) with `-`→`_`) + `_` + upper(k with `-`→`_`) | `OKDP_TRINO_CATALOGS_LAKE_CLIENT_ID` |
| contract reference | `<name>@<major>` (major = first dot-separated field of `metadata.version`) | `postgresql-database@2` |

## 4. Instances and connections

1. Every `spec.instances.<name>` is an instance. Its namespace is `namespace`, defaulting to `spec.namespace`.
2. Every connection in mode `dedicated` adds an instance named as in §3, of `provider.service`, with `provider.parameters`, in the consumer's namespace. It has no connections.
3. For each instance and each `connect.<slot>`: if the slot is `many: true` the value is a map key → connection, else it is one connection with key `""`. Keys are kept as written.
4. **Provider.** For a dedicated connection the provider is the instance of rule 2 (internal). Otherwise `provider` must name an instance (internal) or an external. **providerKind** = `service/<service of the provider instance>` or `external/<external.kind>`. **providerNs** = the provider instance's namespace; for an external, `spec.namespace`.

## 5. Contract choice

1. **Offers.** Internal provider: the `provides[].contract` entries whose `modes` contain the connection mode, in definition order. External: `externals.<x>.offers`, in order (externals offer every mode).
2. If `connection.contract` is set it is the contract; it must be in the offers (error E8) and in `slot.accepts` (E10).
3. Else the candidates are the offers that are also in `slot.accepts`. Exactly one is required: zero → E9, more than one → E11. The chosen contract must exist in the catalog.
4. **Mode bind.** Mode `bind` connects to an endpoint without provisioning. It requires a contract whose `secret.required` is empty (E13). There is no provisioner, no Secret and no unit.

## 6. Provisioner

For modes other than `bind`: in the ProvisionerSet whose `spec.contract` is the chosen contract, take the first provisioner (file order) whose `provider` equals providerKind and whose `modes` contain the mode; if none, the first with `provider: any` and the mode. None at all → E15.

## 7. Claim and binding values

**Claim.** Shallow merge (each layer replaces top-level keys of the previous): (1) the `default` of each top-level property of `contract.spec.claim`; (2) `slot.defaults[<contract name>]`; (3) `connection.claim`. The result must validate against `contract.spec.claim` (JSON Schema 2020-12; all schemas are closed) → else E16.

**Binding values.** Shallow merges, in order:
1. the `default` of each top-level property of `contract.spec.binding`;
2. the **offer** values:
   - mode `existing`: `connection.binding` (required, E14);
   - internal provider: the provider service's offer for this contract (§10), given the **offer input** below;
   - external provider: the external offer for this contract (§10.1);
3. `technology` = `contract.spec.technology` (always set, overrides);
4. **derived values**: for each `key: template` in `contract.spec.derived` (any order) whose key is **absent** after step 3, the template with each `{name}` replaced by the value of `name` after step 3. Strings are inserted as is, integers in decimal, booleans as `true`/`false`. A placeholder naming an absent key → E17. Derived values never see each other.

The result must validate against `contract.spec.binding` → else E16.

**Offer input** (what a provider's offer may read): `instance` (provider), `namespace` (providerNs), `parameters` (provider instance parameters, `{}` for externals), `profile`, `consumer`, `consumerNamespace`, `id`, `suffix`, `ident`, `claim` (merged), `secretName` (or null), and `providerBindings`: the provider instance's **own** bindings by slot (same shape as the mapping input `bindings` of §9.3; `{}` for dedicated and external providers). An offer that reads `providerBindings` makes the consumer's binding depend on the provider's bindings; compute bindings in dependency order (the instance graph is acyclic in a valid platform).

**Binding record** (stored in `plan.bindings[id]`, and passed to mappings and offers): `{consumer, slot, key, contract (name@major), provider, providerKind, mode, namespace (consumer's), provisioner (name or null), secretName (or null), unit (or null), claim, values}`.

## 8. Units

### 8.1 Service units (one per instance, or one per component)

For each instance (declared or dedicated), with service definition *sd*:
- `kind`: `operator` if `sd.offersCapabilities` is non-empty, else `service`.
- `namespace`: the instance namespace. `service`: `<sd name>@<sd version>`.
- `chart`: the chart (or the component chart). A chart whose `repository` is the literal `okdp` is a **catalog chart**: the unit chart becomes `{repository: delivery.okdpCharts, name, version, path: "charts/<name>"}`. Other charts are copied as `{repository, name, version}`.
- `values`: **disjoint deep merge** of the static values (`spec.values`, or `components[i].values`) and the mapping output (`out`, or `out.<component name>`; absent → `{}`; mapping `none` → `{}`). Maps merge recursively; a leaf (scalar or list) set on both sides must be equal (else error); lists are never merged element-wise.
- `needs` = sorted (byte order), de-duplicated union of:
  1. the units of the instance's bindings that have a unit;
  2. for each binding **without** a unit whose provider is internal: all units of the provider instance (its unit, or all its component units);
  3. **capability edges**: for each capability *c* in `sd.capabilities` ∪ `sd.profileCapabilities[f]` for every profile key *f* that the platform profile sets (in that order, duplicates allowed), unless *c* ∈ `preinstalledCapabilities`: all units of every instance whose service offers *c*;
  4. for a component unit: `<instance>-<d>` for each `d` in the component's `needs`.

### 8.2 Provisioner units (one per binding with a unit)

- `kind: provisioner`, `namespace`: the consumer's namespace (cross-namespace bindings land in the consumer's namespace; the chart may create provider-side objects in the provider namespace).
- `chart`: `{repository: delivery.okdpCharts, name, version, path}` of the provisioner. `service`: `provisioner/<contract name@major>/<provisioner name>`.
- `values`:
  - `binding` (all modes): `{secretName, contract (name, no major), bindingType (contract.secret.bindingType), consumer, slot, provider, values}` (`slot` is the slot name, without key);
  - mode `existing`: plus `secretStore` (platform `spec.secretStore`) and `source: {key, properties}` (from `connection.secret`);
  - other modes: plus the offer's provisioner values (§10), deep-merged with `binding` (disjoint).
- `needs` = sorted, de-duplicated: all units of the internal provider (if any), plus capability edges (as 8.1.3) of `provisioner.capabilities`.

### 8.3 Waves
`wave` = length of the longest `needs` path from the unit (0 if no needs). A dependency cycle is an error (E18).

## 9. Mappings

### 9.1 What a mapping is
A mapping turns an instance's resolved bindings into the chart values of its unit(s). It is the only engine-dependent part of the catalog: each engine has its own copy, written in its own language, and must reproduce §10 exactly. A service definition names its mapping (`mapping:`); `none` means static values only.

### 9.2 Offers
A provider service's mapping also holds one **offer** per contract it provides (§7). Externals have **external offers** keyed by contract (§10.1). An offer returns `binding` (values) and `provisioner` (extra provisioner unit values, `{}` for bind-only contracts).

### 9.3 Mapping input
`{instance, namespace, parameters, profile, bindings}` where `bindings.<slot>` is the binding record (§7) or `null` for a single slot, and a map `key → binding record` (possibly empty) for a `many` slot. Every slot of the definition is present.

## 10. Normative mappings (CUE files in `engine-cue/mappings/`)

Conventions used below: `H(x)` = public host of instance x; `has(k)` = the profile sets k; `ing` = ingress block emitted only if `has(domain)`, with class `profile.ingressClass` (if set), annotation `cert-manager.io/cluster-issuer: <profile.clusterIssuer>` (if set), host `H(instance)` and TLS secret `<instance>-tls`; `CA` = volume `{name: okdp-cacerts, secret: {secretName: profile.trustBundle}}` mounted read-only at `/cacerts`, only if `has(trustBundle)`; `secretEnv(b, k, NAME)` = `{name: NAME, valueFrom: {secretKeyRef: {name: b.secretName, key: k}}}`; `bindingEnv(b)` = one `secretEnv(b, k, env(b,k))` per key of `contract.secret.required` in order (empty if b is null or has no Secret). Exact strings, list orders and conditional keys are in the golden plans.

### 10.1 External offer: postgresql-database (provider `external/postgresql-server`, mode tenant)
binding `{host: endpoint.host, port: endpoint.port [5432], database: claim.database [ident], sslMode: endpoint.sslMode [prefer]}`; provisioner `{mode: external-tenant, role: ident, privileges: claim.privileges, external: {adminSecretName: adminSecretRef}}`.

### 10.2 Providers
| Service (mapping) | Instance values (`out`) | Offer: contract → binding | Offer → provisioner values |
|---|---|---|---|
| postgresql-cnpg | `fullnameOverride: <i>-cluster`; `cluster.instances` [1]; `cluster.storage.size` [1Gi]; `cluster.storage.storageClass` if has(storageClass) | postgresql-database: `host <i>-cluster-rw.<ns>.svc`, `port 5432`, `database` claim.database [ident], `sslMode prefer` | `{mode: tenant, role: ident, privileges, cnpg: {clusterName: <i>-cluster, namespace: <ns>}}` |
| seaweedfs | `fullnameOverride: <i>`; `allInOne.data: {type: persistentVolumeClaim, size: parameters.storageSize [2Gi], storageClass if has}` | s3-bucket: `endpoint http://<i>-all-in-one.<ns>.svc.cluster.local:8333`, `region us-east-1`, `pathStyle true`, `bucket` claim.bucket [suffix], `prefix`, `access` from claim | `{seaweedfs: {master: <i>-all-in-one.<ns>.svc.cluster.local:9333}, identity: suffix}` |
| keycloak (components `secrets`, `server`) | secrets: `secrets: [{name: <i>-admin, keys: {admin-password: 32}}]`; server: `fullnameOverride`, `auth` (admin, existingSecret `<i>-admin`), `externalDatabase` from the db Secret keys, `extraEnvVars` [KC_DB (`mysql` if technology mysql else `postgres`), KC_DB_URL = jdbcUrl, KC_DB_USERNAME/PASSWORD, KC_HOSTNAME `https://H(i)`, KC_METRICS_ENABLED, KC_TRACING_ENABLED, KC_CACHE], `ingress` | oidc-client: issuer `https://H(i)/realms/okdp`; `clientId` claim.clientId [suffix]; `authorizeUrl/tokenUrl/userinfoUrl/jwksUrl` = issuer + `/protocol/openid-connect/{auth,token,userinfo,certs}`; `scope` = claim.scopes joined by one space | `{keycloak: {url: http://<i>.<ns>.svc.cluster.local, realm: okdp, adminUser: admin, adminSecretName: <i>-admin, namespace}, client: {clientId, redirectUris: https://H(consumer)+path per redirectPaths, webOrigins: [https://H(consumer)], scopes, public, serviceAccount}, probe: {caSecret: profile.trustBundle [""]}}` |
| hive-metastore | `serviceName: <i>`; `db` (driverRef `com.mysql.cj.jdbc.Driver` if mysql else `org.postgresql.Driver`, driverName = technology, host, port, databaseName, password from Secret); `s3` (url = endpoint, warehouseDirectory = bucket, keys from Secret); `extraEnvRaw` [HIVEMS_USER, THRIFT_LISTENING_PORT=9083] | hive-metastore (bind): `thriftUri thrift://<i>.<ns>.svc.cluster.local:9083`, `warehouse` = providerBindings.warehouse.values.rootUri [""] | `{}` |
| polaris (components `bootstrap`, `server`) | bootstrap: `{realm: okdp, rootSecretName: <i>-root, db.secretName}`; server: `fullnameOverride`, `realmContext {type: default, realms: [okdp]}`, `persistence.relationalJdbc.secret` (db Secret, keys username/password/jdbcUrl), `storage.secret` (storage Secret), `extraEnv [AWS_REGION]` | iceberg-rest-catalog: `uri http://<i>.<ns>.svc.cluster.local:8181/api/catalog`, `warehouse` claim.warehouse [ident], `scope PRINCIPAL_ROLE:ALL` | `{polaris: {url, realm: okdp, rootSecretName, namespace}, catalog: {name: warehouse, baseLocation: s3://<bucket>/[<prefix>/]<warehouse>, endpoint, region, pathStyle} (from providerBindings.storage.values), principal: suffix, access}` |
| trino (components `secrets`, `server`) | see 10.3 | trino (bind): `host <i>.<ns>.svc.cluster.local`, `port 8080`, `catalogs` = sorted keys of providerBindings.catalogs | `{}` |
| trust-manager | `app.trust.namespace: <ns>`; `secretTargets.authorizedSecrets: [profile.trustBundle]` (or `[]`) | – | – |
| platform-trust | `{issuer: profile.clusterIssuer, bundle: profile.trustBundle, trustNamespace: <ns>}` | – | – |
| ingress-nginx | `fullnameOverride: <i>`; if has(ingressClass): `controller.ingressClassResource.name` and `controller.ingressClass` | – | – |
| coredns-rewrite | `{domain: profile.domain, target: parameters.target}` | – | – |

### 10.3 Consumers
- **trino** (`out.secrets`: `[{name: <i>-internal, keys: {shared-secret: 64}}]`; `out.server`): `fullnameOverride`; `server.workers` = parameters.workers [1]; `coordinator.config.nodeScheduler.includeCoordinator` = (workers == 0); `catalogs.<key>`: lines joined by `\n` — Iceberg REST (`connector.name=iceberg`, `iceberg.catalog.type=rest`, uri, warehouse, `security=OAUTH2`, `oauth2.credential=${ENV:<client-id env>}:${ENV:<client-secret env>}`, scope, server-uri, `vended-credentials-enabled=false`) or Hive (`connector.name=hive`, `hive.metastore.uri`), followed, if `catalogStorage.<same key>` exists, by the S3 lines (`fs.native-s3.enabled=true`, endpoint, region, path-style-access, `${ENV}` keys); `env` = `TRINO_SHARED_SECRET` then bindingEnv of catalogs (key order) then catalogStorage (key order) then identity; `additionalConfigProperties` (shared secret, process-forwarded); if identity: `server.coordinatorExtraConfig` (8 OAuth2 lines); if has(trustBundle): `secretMounts` + JVM truststore flags; `ing` (chart shape `hosts: [{host, paths}]`).
- **superset** (`out.secrets`: `{secret-key: 64, redis-password: 32}` in `<i>-internal`; `out.server`): `fullnameOverride`; `supersetNode.connections` (db host/port as string/name, `redis_password: set-from-env`); `redis.auth`; `extraEnvRaw` [DB_USER, DB_PASS, REDIS_PASSWORD, SUPERSET_SECRET_KEY, bindingEnv(identity), REQUESTS_CA_BUNDLE if CA]; `configOverrides.okdp_database` (SQLALCHEMY_DATABASE_URI = metadataDb sqlalchemyUrl with quoted DB_USER/DB_PASS inserted after `://`); `configOverrides.okdp_auth` if identity (Keycloak OAuth provider, role mapping, `AUTH_API_LOGIN_ALLOW_MULTIPLE_PROVIDERS = True`); `extraConfigs."import_datasources.yaml"` if datasources (one database per key, sorted; `extra` = `{"engine_params":{"connect_args":{"user":"<i>","http_scheme":"http"}}}`); `init: {createAdmin: false, loadExamples: false}`; CA; `ing` (chart shape `hosts: [host]`, path `/`, pathType Prefix, proxy-buffer-size annotation).
- **jupyterhub**: if hubDb: `hub.db = {type: other, url: sqlalchemyUrl}` and `hub.extraConfig.okdp-db` (inserts the quoted credentials of the hubDb env vars into `c.JupyterHub.db_url`); `hub.extraEnv` (map) = bindingEnv of storage and catalogs + endpoint vars (`OKDP_STORAGE_ROOT_URI`, `OKDP_STORAGE_S3_ENDPOINT` for s3, `OKDP_CATALOG_<KEY>_URI`, `OKDP_CATALOG_<KEY>_WAREHOUSE`) + bindingEnv(hubDb) + `OAUTH_CLIENT_SECRET` (identity); `singleuser.extraEnv` = the same without hubDb and OAUTH; if identity: `hub.config.JupyterHub.authenticator_class: generic-oauth` and `hub.config.GenericOAuthenticator` (client_id, callback `https://H(i)/hub/oauth_callback`, URLs, scope split on spaces, claims, allowed/admin groups, `validate_server_cert: false`); `ing`.
- **spark-history** (`out.secrets`: `{cookie-key: 32}` in `<i>-internal`; `out.server`; `out.proxy`): server `fullnameOverride: <i>-server`; `config` (logDirectory = eventLog rootUri, s3a endpoint/path style/region, cleaner, and the OIDC filter keys if identity); `extraEnvs` [AWS keys, AUTH_CLIENT_ID, AUTH_CLIENT_SECRET, AUTH_COOKIE_ENCRYPTION_KEY (identity), JAVA_TOOL_OPTIONS (CA)]; CA. proxy: `configuration.spark.history.service: <i>-server.<ns>.svc.cluster.local`, `jobNamespaces: [<ns>]`, `ing`.

## 11. Errors

The engine fails (exit ≠ 0, no plan) when any of these holds. Each message must contain the quoted phrase, with the placeholders filled. Report all errors found, one per line, `ERROR: ` prefixed, when possible.

| # | Condition | Phrase |
|---|---|---|
| E1 | unknown service | `instance <i>: unknown service "<s>"` |
| E2 | unknown slot | `instance <i>: service <s> has no slot "<slot>"` |
| E3 | required slot not connected | `instance <i>: required slot "<slot>" is not connected` |
| E4 | profile key required by the service missing | `instance <i>: service <s> requires profile.<key>` |
| E5 | catalog: neither or both of chart/components; unknown component need; slot with an empty `accepts`; unknown provided contract | `service <s>: …` |
| E6 | catalog: a derived key or placeholder is not a binding property of its contract | `contract <c>: …` |
| E7 | unknown provider | `connection <id>: unknown provider "<p>"` |
| E8 | explicit contract not offered | `connection <id>: provider <p> does not offer contract <c> in mode <m>` |
| E9 | no offered contract accepted by the slot | `connection <id>: slot <slot> accepts [<accepts, ", ">]; provider <p> offers [<offers, ", ">] in mode <m>` |
| E10 | explicit contract not accepted by the slot | `connection <id>: slot <slot> accepts [<accepts, ", ">], not contract <c>` |
| E11 | several offered contracts accepted by the slot | `connection <id>: ambiguous contract [<candidates, ", ">]: name one with contract:`  |
| E13 | bind on a contract with secret keys | `connection <id>: mode bind needs a contract without secret keys` |
| E14 | mode existing without `binding:` | `connection <id>: mode existing needs` |
| E15 | no provisioner | `connection <id>: no provisioner for contract <c>, provider <kind>, mode <m>` |
| E16 | claim or binding violates its schema | the JSON-Schema path and reason (e.g. `claim.superuser: field not allowed`, `values.port`, `out of bound`) |
| E17 | derived template references an absent value | `connection <id>: derived value of contract <c> references "<name>"` |
| E18 | dependency cycle | any message containing `cycle` |
| E19 | missing capability | `unit <u>: capability "<c>" is neither provided by an instance nor declared preinstalled` |

## 12. Output and v1 → v2 changes

`plan.json` validates against `schema/plan.schema.json` (v2: binding `mode` may be `bind`, `provisioner` may be null). Engines are compared with `jq -S`.

Changes from v1 (this demo returns to `slot.accepts`: no families, no slot `technologies`, §5); derived binding values (§7); `technology` in every binding; components (§8.1); static `values` merged with mappings; catalog charts (`repository: okdp`); `profile`, `profileCapabilities`, `requiresProfile`; mode `bind`; `providerBindings` in offers; provisioner unit values always carry `binding.values` (nested, all modes) and the provider namespace when the chart works across namespaces; `needs` are de-duplicated and expand to all component units.
