{{- /*
Shared by the OKDP binding provisioner charts (copied verbatim into each chart; see catalog/charts/_shared).
Values contract (filled by the composition engine): .Values.binding = {secretName, contract, bindingType,
consumer, slot, provider, values}. The release namespace is the consumer namespace.
*/ -}}

{{- define "okdp.suffix" -}}{{ trimPrefix "okdp-bind-" .Values.binding.secretName }}{{- end -}}
{{- define "okdp.srcName" -}}okdp-src-{{ include "okdp.suffix" . }}{{- end -}}
{{- define "okdp.hash" -}}{{ toJson .Values | sha256sum | trunc 8 }}{{- end -}}

{{- define "okdp.bindingLabels" -}}
okdp.io/binding: "true"
okdp.io/contract: {{ .Values.binding.contract | quote }}
okdp.io/consumer: {{ .Values.binding.consumer | quote }}
okdp.io/slot: {{ .Values.binding.slot | quote }}
okdp.io/provider: {{ .Values.binding.provider | quote }}
{{- end -}}

{{- define "okdp.requireBinding" -}}
{{- range $k := list "secretName" "contract" "bindingType" "consumer" "slot" "provider" -}}
{{- if not (index $.Values.binding $k) -}}{{- fail (printf "binding.%s is required" $k) -}}{{- end -}}
{{- end -}}
{{- end -}}

{{- /* ExternalSecret template data: Service Binding "type" and "provider", then every binding value as a string */ -}}
{{- define "okdp.bindingData" -}}
type: {{ .Values.binding.bindingType | quote }}
provider: {{ .Values.binding.provider | quote }}
{{- range $k, $v := .Values.binding.values }}
{{ $k }}: {{ if kindIs "slice" $v }}{{ join "," $v | quote }}{{ else }}{{ $v | toString | quote }}{{ end }}
{{- end }}
{{- end -}}

{{- /*
Cross-namespace copy: the provider-side Secret <okdp.srcName> (provider namespace) is read by the consumer
namespace through a namespaced ESO SecretStore (Kubernetes provider) whose ServiceAccount may only `get`
that one Secret. Argument: dict "root" . "ns" <provider namespace>.
*/ -}}
{{- define "okdp.copyStore" -}}
{{- $src := include "okdp.srcName" .root -}}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ $src }}
  namespace: {{ .root.Release.Namespace }}
  labels: {{- include "okdp.bindingLabels" .root | nindent 4 }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ $src }}
  namespace: {{ .ns }}
  labels: {{- include "okdp.bindingLabels" .root | nindent 4 }}
rules:
  - { apiGroups: [""], resources: [secrets], resourceNames: [{{ $src }}], verbs: [get] }
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ $src }}
  namespace: {{ .ns }}
  labels: {{- include "okdp.bindingLabels" .root | nindent 4 }}
roleRef: { apiGroup: rbac.authorization.k8s.io, kind: Role, name: {{ $src }} }
subjects: [ { kind: ServiceAccount, name: {{ $src }}, namespace: {{ .root.Release.Namespace }} } ]
---
apiVersion: external-secrets.io/v1
kind: SecretStore
metadata:
  name: {{ $src }}
  namespace: {{ .root.Release.Namespace }}
  labels: {{- include "okdp.bindingLabels" .root | nindent 4 }}
spec:
  provider:
    kubernetes:
      remoteNamespace: {{ .ns }}
      server: { caProvider: { type: ConfigMap, name: kube-root-ca.crt, key: ca.crt } }
      auth: { serviceAccount: { name: {{ $src }} } }
{{- end -}}

{{- /* Provider-side generated source Secret: one ESO Password generator + ExternalSecret (created once).
Argument: dict "root" . "ns" <namespace> "data" <ExternalSecret template data (string)> "type" <Secret type or ""> */ -}}
{{- define "okdp.generatedSource" -}}
{{- $src := include "okdp.srcName" .root -}}
apiVersion: generators.external-secrets.io/v1alpha1
kind: Password
metadata:
  name: {{ $src }}
  namespace: {{ .ns }}
  labels: {{- include "okdp.bindingLabels" .root | nindent 4 }}
spec: { length: 32, digits: 6, symbols: 0, noUpper: false, allowRepeat: true }
---
apiVersion: external-secrets.io/v1
kind: ExternalSecret
metadata:
  name: {{ $src }}
  namespace: {{ .ns }}
  labels: {{- include "okdp.bindingLabels" .root | nindent 4 }}
spec:
  refreshPolicy: CreatedOnce
  target:
    name: {{ $src }}
    creationPolicy: Owner
    template:
      {{- if .type }}
      type: {{ .type }}
      {{- end }}
      metadata:
        labels: {{- include "okdp.bindingLabels" .root | nindent 10 }}
      data: {{- .data | nindent 8 }}
  dataFrom:
    - sourceRef:
        generatorRef: { apiVersion: generators.external-secrets.io/v1alpha1, kind: Password, name: {{ $src }} }
{{- end -}}

{{- /* Consumer-side binding Secret copied from the source through the store.
Argument: dict "root" . "keys" (list of source keys to copy) "extra" <extra template data (string)> */ -}}
{{- define "okdp.bindingFromSource" -}}
{{- $src := include "okdp.srcName" .root -}}
apiVersion: external-secrets.io/v1
kind: ExternalSecret
metadata:
  name: {{ .root.Values.binding.secretName }}
  namespace: {{ .root.Release.Namespace }}
  labels: {{- include "okdp.bindingLabels" .root | nindent 4 }}
spec:
  refreshInterval: 10m
  secretStoreRef: { kind: SecretStore, name: {{ $src }} }
  target:
    name: {{ .root.Values.binding.secretName }}
    creationPolicy: Owner
    template:
      engineVersion: v2
      metadata:
        labels: {{- include "okdp.bindingLabels" .root | nindent 10 }}
      data:
        {{- include "okdp.bindingData" .root | nindent 8 }}
        {{- range $k := .keys }}
        {{ $k }}: {{ printf "{{ index . %q }}" $k | quote }}
        {{- end }}
        {{- with .extra }}{{ . | nindent 8 }}{{ end }}
  data:
    {{- range $k := .keys }}
    - { secretKey: {{ $k }}, remoteRef: { key: {{ $src }}, property: {{ $k }} } }
    {{- end }}
{{- end -}}
