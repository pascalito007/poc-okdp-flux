#!/bin/sh
# T4 (Pkl) composition engine: compose.sh <platform.yaml> <out-dir>  ->  <out-dir>/plan.json
# Errors (ENGINE-SPEC §11) are printed one per line, prefixed "ERROR: ", exit code 1, no plan.
set -eu
[ $# -eq 2 ] || { echo "usage: $0 <platform.yaml> <out-dir>" >&2; exit 2; }
HERE="$(cd "$(dirname "$0")" && pwd)"
POC="$(cd "$HERE/.." && pwd)"
PLATFORM="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
OUT="$2"
CATALOG="${OKDP_CATALOG:-$POC/catalog}"
mkdir -p "$OUT"
TMP="$(mktemp "${TMPDIR:-/tmp}/okdp-pkl.XXXXXX")"
trap 'rm -f "$TMP" "$TMP.err"' EXIT
if pkl eval "$HERE/engine/compose.pkl" -p catalog="$CATALOG" -p platform="$PLATFORM" -o "$TMP" 2>"$TMP.err"; then
  mv "$TMP" "$OUT/plan.json"
else
  rm -f "$OUT/plan.json"
  if grep -q '^ERROR: ' "$TMP.err"; then
    grep '^ERROR: ' "$TMP.err" | awk '!seen[$0]++' >&2
  else
    cat "$TMP.err" >&2
  fi
  exit 1
fi
