#!/bin/sh
# T4 (Pkl) emitters: emit.sh <out-dir> [target...]  reads <out-dir>/plan.json only and writes helm/, helmfile/,
# umbrella/, argocd/, flux/ and INSTALL.md next to it.
set -eu
[ $# -ge 1 ] || { echo "usage: $0 <out-dir> [target...]" >&2; exit 2; }
# optional targets (helm helmfile umbrella argocd flux; default: all): the others are removed after emission
all_targets="helm helmfile umbrella argocd flux"
dir_arg=$1; shift; targets="${*:-$all_targets}"
for t in $targets; do case " $all_targets " in *" $t "*) ;; *) echo "ERROR: unknown target '$t' (expected: $all_targets)" >&2; exit 2;; esac; done
set -- "$dir_arg"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(cd "$1" && pwd)"
[ -f "$OUT/plan.json" ] || { echo "emit: $OUT/plan.json not found" >&2; exit 1; }
rm -rf "$OUT/helm" "$OUT/helmfile" "$OUT/umbrella" "$OUT/argocd" "$OUT/flux" "$OUT/INSTALL.md"
pkl eval "$HERE/emit/emit.pkl" -p plan="$OUT/plan.json" -m "$OUT" >/dev/null
chmod +x "$OUT/helm/deploy.sh"
for t in $all_targets; do case " $targets " in *" $t "*) ;; *) rm -rf "$OUT/$t";; esac; done
