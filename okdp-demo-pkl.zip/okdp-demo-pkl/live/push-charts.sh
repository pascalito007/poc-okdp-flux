#!/bin/sh
# Packages every catalog chart (catalog/charts/*, except _shared) and pushes it to an OCI registry.
# Usage: live/push-charts.sh [registry]   (default oci://localhost:5001/okdp, plain HTTP)
set -eu
cd "$(dirname "$0")/.."
reg=${1:-oci://localhost:5001/okdp}
tmp=$(mktemp -d)
for c in catalog/charts/*/; do
  case "$c" in */_shared/) continue;; esac
  helm package "$c" -d "$tmp" >/dev/null
done
for t in "$tmp"/*.tgz; do helm push "$t" "$reg" --plain-http 2>&1 | grep -E "^Pushed" ; done
rm -rf "$tmp"
