#!/bin/sh
# In-cluster Git server for the Argo CD demo: git://okdp-git.okdp-git.svc/okdp-gitops. Each platform has its own
# folder <platform>/argocd in the repository, so the root Applications of several platforms do not overlap.
# Usage: CONTEXT=<kube-context> demo/git-server.sh                        (re)start the server, content kept
#        CONTEXT=<kube-context> demo/git-server.sh <platform> <out-dir>   publish <out-dir>/argocd as <platform>/argocd
#        CONTEXT=<kube-context> demo/git-server.sh --remove <platform>    remove the folder of <platform>
set -eu
K="kubectl --context ${CONTEXT:-kind-okdp-poc}"
. "$(dirname "$0")/proxy.sh"
mode=keep; platform=""; src=""
case "${1:-}" in
  "") ;;
  --remove) mode=remove; platform=${2:?usage: git-server.sh --remove <platform>} ;;
  *) mode=publish; platform=$1; src=${2:?usage: git-server.sh <platform> <out-dir>} ;;
esac
$K create ns okdp-git --dry-run=client -o yaml | $K apply -f - >/dev/null

# The repository content is the ConfigMap gitops-files: one key per file, "/" written "__"
# (e.g. trino-tenant__argocd__apps__hive.yaml). Rebuild it: the other platforms' files are kept,
# this platform's files are replaced (publish) or dropped (remove).
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
cur=$($K -n okdp-git get configmap gitops-files -o json 2>/dev/null || echo '{}')
for key in $(printf "%s" "$cur" | jq -r '.data // {} | keys[]'); do
  case "$key" in "${platform}__"*) [ "$mode" = keep ] || continue ;; esac
  printf "%s" "$cur" | jq -j --arg k "$key" '.data[$k]' > "$tmp/$key"
done
if [ "$mode" = publish ]; then
  for f in $(cd "$src" && find argocd -type f | sort); do cp "$src/$f" "$tmp/${platform}__$(echo "$f" | sed 's#/#__#g')"; done
fi
[ -f "$tmp/README.md" ] || printf 'OKDP demo GitOps repository: one folder per platform, <platform>/argocd.\n' > "$tmp/README.md"
# replace (not apply): no last-applied annotation, so no 256 KB limit
$K -n okdp-git create configmap gitops-files --from-file="$tmp" --dry-run=client -o yaml > "$tmp.cm.yaml"
if $K -n okdp-git get configmap gitops-files >/dev/null 2>&1; then $K replace -f "$tmp.cm.yaml" >/dev/null
else $K create -f "$tmp.cm.yaml" >/dev/null; fi
rm -f "$tmp.cm.yaml"
echo "   repository: $(ls "$tmp" | sed -n 's/__argocd__kustomization.yaml$//p' | tr '\n' ' ')"
cat <<'YAML' | $K apply -f - >/dev/null
apiVersion: apps/v1
kind: Deployment
metadata: { name: okdp-git, namespace: okdp-git }
spec:
  replicas: 1
  selector: { matchLabels: { app: okdp-git } }
  template:
    metadata: { labels: { app: okdp-git } }
    spec:
      volumes: [ { name: files, configMap: { name: gitops-files } } ]
      containers:
        - name: git
          image: alpine:3.20
          command: ["/bin/sh", "-ec"]
          args:
            - |
              apk add --no-cache git git-daemon >/dev/null
              mkdir -p /work && cd /work
              for f in /files/*; do p=$(basename "$f" | sed 's#__#/#g'); mkdir -p "$(dirname "$p")"; cp "$f" "$p"; done
              git init -q -b main . && git add . && git -c user.name=okdp -c user.email=poc@okdp.local commit -qm "generated artefacts"
              git clone -q --bare /work /srv/okdp-gitops && touch /srv/okdp-gitops/git-daemon-export-ok
              exec git daemon --reuseaddr --base-path=/srv --export-all /srv
          ports: [ { containerPort: 9418 } ]
          readinessProbe: { tcpSocket: { port: 9418 }, periodSeconds: 2, failureThreshold: 150 }
          volumeMounts: [ { name: files, mountPath: /files } ]
---
apiVersion: v1
kind: Service
metadata: { name: okdp-git, namespace: okdp-git }
spec: { selector: { app: okdp-git }, ports: [ { port: 9418, targetPort: 9418 } ] }
YAML
# behind a corporate proxy the pod's "apk add" needs it (found by demo/proxy.sh)
if [ -n "$OKDP_PROXY" ]; then
  $K -n okdp-git set env deploy/okdp-git http_proxy="$OKDP_PROXY" https_proxy="$OKDP_PROXY" \
    HTTP_PROXY="$OKDP_PROXY" HTTPS_PROXY="$OKDP_PROXY" NO_PROXY="$OKDP_NO_PROXY" no_proxy="$OKDP_NO_PROXY" >/dev/null
fi
$K -n okdp-git rollout restart deploy/okdp-git >/dev/null
# ready only once git daemon listens (the probe), so a failed "apk add" stops here instead of later in Argo CD
if ! $K -n okdp-git rollout status deploy/okdp-git --timeout=300s; then
  echo "ERROR: the git server did not start. Its log:" >&2; $K -n okdp-git logs deploy/okdp-git --tail=15 >&2 || true
  echo "Behind a proxy: set OKDP_PROXY=http://<proxy ip>:<port> (proxy found: ${OKDP_PROXY:-none})" >&2; exit 1
fi
