# Sourced by demo/argocd-install.sh and demo/git-server.sh: finds the corporate proxy the pods must use.
# Sets OKDP_PROXY (http://<ip>:<port>, or empty when there is no proxy), OKDP_NO_PROXY and OKDP_CA_FILE.
#   - OKDP_PROXY already set: kept as is (OKDP_PROXY=none disables the proxy);
#   - else taken from the workstation's HTTPS_PROXY / HTTP_PROXY (or lower case), with the host name
#     replaced by its IP address: the workstation resolves the proxy name, the pods may not;
#   - OKDP_CA_FILE: when a proxy is used and it is not set, the workstation's CA bundle if one exists
#     (a proxy that inspects TLS signs with a CA the pods do not know).

okdp_resolve() { # host name -> first IPv4 address (empty if unknown)
  if command -v getent >/dev/null 2>&1; then getent ahostsv4 "$1" 2>/dev/null | awk 'NR==1 {print $1}'
  else python3 -c 'import socket,sys; print(socket.gethostbyname(sys.argv[1]))' "$1" 2>/dev/null; fi
}

if [ "${OKDP_PROXY:-}" = none ]; then
  OKDP_PROXY=""
elif [ -z "${OKDP_PROXY:-}" ]; then
  _p=${HTTPS_PROXY:-${https_proxy:-${HTTP_PROXY:-${http_proxy:-}}}}
  if [ -n "$_p" ]; then
    _hp=${_p#*://}; _hp=${_hp#*@}; _hp=${_hp%%/*}          # host:port (scheme, credentials and path removed)
    _h=${_hp%:*}; _port=${_hp##*:}; [ "$_port" = "$_hp" ] && _port=3128
    case "$_h" in
      *[!0-9.]*) _ip=$(okdp_resolve "$_h") ;;            # a name: resolve it on the workstation
      *) _ip=$_h ;;                                       # already an IP
    esac
    if [ -n "$_ip" ]; then OKDP_PROXY="http://$_ip:$_port"
    else echo "WARNING: proxy $_p found but $_h does not resolve: set OKDP_PROXY=http://<ip>:<port>" >&2; OKDP_PROXY=""; fi
  fi
fi
OKDP_PROXY=${OKDP_PROXY:-}
OKDP_NO_PROXY=${OKDP_NO_PROXY:-kind-registry,.svc,.cluster.local,localhost,127.0.0.1}
if [ -n "${OKDP_PROXY:-}" ] && [ -z "${OKDP_CA_FILE:-}" ] && [ -f /etc/ssl/certs/ca-certificates.crt ]; then
  OKDP_CA_FILE=/etc/ssl/certs/ca-certificates.crt
fi
OKDP_CA_FILE=${OKDP_CA_FILE:-}
