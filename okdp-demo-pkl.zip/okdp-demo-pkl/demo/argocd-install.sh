#!/bin/sh
# Step 1 of the Argo CD demo, run once before presenting: installs Argo CD, an in-cluster git server (its content
# is kept if it exists), and the repository Secrets of the OKDP chart registry and of that git server.
# Afterwards Argo CD runs with no Application at all. Step 2 (after compose + emit): demo/argocd-publish.sh.
# Usage: demo/argocd-install.sh <kube-context>     e.g. demo/argocd-install.sh kind-okdp-b
# Behind a corporate proxy (DGFiP workstation) nothing to do: the proxy is taken from HTTP(S)_PROXY, its IP
# resolved on the workstation, and the workstation CA bundle mounted (demo/proxy.sh; override: OKDP_PROXY,
# OKDP_NO_PROXY, OKDP_CA_FILE, or OKDP_PROXY=none).
set -eu
[ $# -eq 1 ] || { echo "usage: $0 <kube-context>   (e.g. $0 kind-okdp-b)" >&2; exit 2; }
cd "$(dirname "$0")/.."
CTX=$1; K="kubectl --context $CTX"
. demo/proxy.sh
echo "== proxy: ${OKDP_PROXY:-none}${OKDP_CA_FILE:+, CA $OKDP_CA_FILE}"
ARGO_VERSION=${ARGO_VERSION:-v3.4.12}
echo "== Argo CD $ARGO_VERSION"
# a namespace being deleted refuses new objects: wait until it is gone
if [ "$($K get ns argocd -o jsonpath='{.status.phase}' 2>/dev/null)" = Terminating ]; then
  echo "   namespace argocd is still being deleted: waiting (5 min max)"
  $K wait --for=delete ns/argocd --timeout=300s || {
    echo "ERROR: namespace argocd is stuck. Remove the finalizers of its remaining Applications:" >&2
    echo "  for a in \$($K -n argocd get applications -o name); do $K -n argocd patch \$a --type merge -p '{\"metadata\":{\"finalizers\":null}}'; done" >&2
    exit 1; }
fi
$K create ns argocd --dry-run=client -o yaml | $K apply -f - >/dev/null
$K apply -n argocd --server-side --force-conflicts -f "https://raw.githubusercontent.com/argoproj/argo-cd/$ARGO_VERSION/manifests/install.yaml" >/dev/null
# components the demo does not use (memory of the 7.7 GB kind VM)
$K -n argocd scale deploy argocd-dex-server argocd-notifications-controller argocd-applicationset-controller --replicas=0 >/dev/null
# behind a corporate proxy the repo-server downloads charts through it
if [ -n "$OKDP_PROXY" ]; then
  echo "== proxy $OKDP_PROXY on argocd-repo-server"
  $K -n argocd set env deploy/argocd-repo-server HTTP_PROXY="$OKDP_PROXY" HTTPS_PROXY="$OKDP_PROXY" NO_PROXY="$OKDP_NO_PROXY" >/dev/null
fi
# a proxy that inspects TLS needs its CA (the workstation CA bundle, found by demo/proxy.sh)
if [ -n "$OKDP_CA_FILE" ]; then
  echo "== CA bundle $OKDP_CA_FILE on argocd-repo-server"
  $K -n argocd create configmap okdp-ca --from-file=ca-certificates.crt="$OKDP_CA_FILE" --dry-run=client -o yaml | $K apply --server-side --force-conflicts --field-manager=okdp-demo -f - >/dev/null
  $K -n argocd patch deploy argocd-repo-server --type strategic -p '{"spec":{"template":{"spec":{
    "volumes":[{"name":"okdp-ca","configMap":{"name":"okdp-ca"}}],
    "containers":[{"name":"argocd-repo-server","volumeMounts":[{"name":"okdp-ca","mountPath":"/etc/okdp-ca"}],
                   "env":[{"name":"SSL_CERT_FILE","value":"/etc/okdp-ca/ca-certificates.crt"}]}]}}}}' >/dev/null
fi
$K -n argocd rollout status statefulset/argocd-application-controller --timeout=600s
$K -n argocd rollout status deploy/argocd-repo-server --timeout=600s
echo "== in-cluster git server (published platforms kept)"
CONTEXT=$CTX demo/git-server.sh
echo "== repositories: OKDP chart registry and git server"
$K apply -f demo/argocd-setup.yaml
echo "ARGO CD READY: $($K -n argocd get applications --no-headers 2>/dev/null | wc -l | tr -d ' ') Application(s)"
