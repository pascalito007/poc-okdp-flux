#!/bin/sh
# Demo wiring for the Argo CD live run of a platform: installs Argo CD, an in-cluster git server holding
# the generated argocd/ folder, the repository Secrets (catalog registry + public OCI chart registries),
# the emitted Application health customization, then the root app-of-apps.
# Usage: demo/full-argocd.sh <kube-context> [platform | artefact-dir]   (default platform full-sandbox)
set -eu
cd "$(dirname "$0")/.."
CTX=$1; s=${2:-full-sandbox}
# the second argument may also be an artefact directory (another toolchain's output)
if [ -d "$s" ]; then d=$(cd "$s" && pwd); s=$(basename "$d"); else d="$PWD/out/$s"; fi; K="kubectl --context $CTX"
ARGO_VERSION=${ARGO_VERSION:-v3.4.12}
$K create ns argocd --dry-run=client -o yaml | $K apply -f - >/dev/null
$K apply -n argocd --server-side --force-conflicts -f "https://raw.githubusercontent.com/argoproj/argo-cd/$ARGO_VERSION/manifests/install.yaml" >/dev/null
# components the demo does not use (memory of the 7.7 GB kind VM)
$K -n argocd scale deploy argocd-dex-server argocd-notifications-controller argocd-applicationset-controller --replicas=0 >/dev/null
$K -n argocd rollout status statefulset/argocd-application-controller --timeout=600s
$K -n argocd rollout status deploy/argocd-repo-server --timeout=600s
CONTEXT=$CTX demo/git-server.sh "$d"
$K apply -f demo/argocd-setup.yaml
# public OCI chart registries used by the plan (Argo CD needs enableOCI for each)
for r in $(jq -r '.units[].chart | select(.path == null) | .repository | select(startswith("oci://"))' "$d/plan.json" | sort -u); do
  n=$(echo "$r" | sed -E 's#oci://##; s#[^a-z0-9]+#-#g')
  $K -n argocd create secret generic "repo-$n" --from-literal=type=helm --from-literal=name="$n" --from-literal=url="${r#oci://}" --from-literal=enableOCI=true --dry-run=client -o yaml \
    | $K label --local -f - argocd.argoproj.io/secret-type=repository -o yaml | $K apply -f - >/dev/null
done
$K apply --server-side --field-manager=okdp-emitter -f "$d/argocd/argocd-cm-application-health.yaml"
$K -n argocd rollout restart statefulset/argocd-application-controller >/dev/null
$K -n argocd rollout status statefulset/argocd-application-controller --timeout=300s
sed 's#REPLACE_WITH_GIT_REPO#git://okdp-git.okdp-git.svc/okdp-gitops#' "$d/argocd/root-application.yaml" > "demo/root-application.$s.yaml"
date -u +%FT%TZ > "demo/argocd-start.$s.txt"
$K apply -f "demo/root-application.$s.yaml"
